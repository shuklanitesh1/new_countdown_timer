class Testdata:
    CHROME_EXECUTABLE_PATH = "C:\\BrowserDrivers\\chromedriver.exe"
    FIREFOX_EXECUTABLE_PATH = "C:\\BrowserDrivers\\geckodriver.exe"

    #BASE_URL = "https://google.com/"
    BASE_URL = "https://e.ggtimer.com/"
    USERNAME = "shukla.nitesh1@gmail.com"
    PASSWORD = "Nitesh@22"

    START_PAGE_TITLE = "e.ggtimer - a simple countdown timer"
