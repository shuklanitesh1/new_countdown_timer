from selenium.webdriver.common.by import By
import time
from Config.config import Testdata
from Pages.BasePage import BasePage


class StartPage(BasePage):
    start_time_input = (By.ID, "EggTimer-start-time-input-text")
    Start_button = (By.XPATH, "//button[contains(text(),'Start')]")
    Five_MIN = (By.LINK_TEXT, "/5 minutes")
    Ten_MIN = (By.LINK_TEXT, "/10 minutes")
    Fifteen_MIN = (By.LINK_TEXT, "/15 minutes")
    Help_Text = (By.XPATH, "//button[normalize-space()='Help and Settings']")
    EGG_Timer_Twitter = (By.XPATH, "//a[normalize-space()='@edotggtimer']")
    PomoDoro = (By.XPATH, "//a[normalize-space()='/Pomodoro']")
    Tabata = (By.XPATH, "//a[normalize-space()='/Tabata']")
    Morning = (By.XPATH, "//a[normalize-space()='/Morning']")
    Welcome_Msg = (By.XPATH, "//div[@class='EggTimer-start-welcome']")
    countdown = (By.XPATH, "//span")
    """Constructor Of the Page Class"""

    def __init__(self, driver):
        super().__init__(driver)
        #self.driver.get(Testdata.BASE_URL)
        self.driver.get('https://e.ggtimer.com/')


    """Page Actions for Start Page """

    """This is used to get the title of the Page"""
    def get_title_start_page(self, title):
        print(self.get_title(title))
        return self.get_title(title)


    """This is used to send Enter the time and click Start"""
    def enter_the_time(self, timeinseconds):
        self.send_key(self.start_time_input, timeinseconds)
        self.do_click(self.Start_button)
        print("click happened")
        time.sleep(3)

    def countdown_handle(self):
        before = ""
        after = ""
        while True:
            after = self.driver.find_element_by_xpath("//span").text
            if after != before:
                print(after)
                before = after
                if before == "Time Expired!":
                    break
                print("Countdown Completed")

            else:
                print("Countdown is still running")

