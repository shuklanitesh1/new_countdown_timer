import time

import pytest
from selenium.webdriver.common.by import By

from Config.config import Testdata
from Pages.StartPage import StartPage
from Test.test_base import BaseTest


# @pytest.mark.usefixtures["init_driver"]  # fixture can be directly used like this as well
class Test_Egg_Timer(BaseTest):

    def test_get_startpage_title(self):
        self.startPage = StartPage(self.driver)
        title = self.startPage.get_title_start_page(Testdata.START_PAGE_TITLE)
        assert title == Testdata.START_PAGE_TITLE

    def test_entertime(self):
        self.enterTime = StartPage(self.driver)
        #enter_time = self.enterTime.enter_the_time(25)
        self.enterTime.enter_the_time(25)
        self.driver.implicitly_wait(3)

    def test_countdown_timer(self):
        self.verifytimer = StartPage(self.driver)
        #verify_timer = self.verifytimer.countdown_handle()
        self.verifytimer.countdown_handle()
        self.driver.implicitly_wait(3)



